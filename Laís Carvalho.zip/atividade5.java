package atividadelingp;
import java.util.Scanner;
public class atividade5 {
	
	public static void main(String[] args) {
		// questão 5
		Scanner teclado=new Scanner(System.in);
		
		int a,b;
		System.out.println("Valor de a: ");
		a= Integer.parseInt(teclado.nextLine());
		
		System.out.println("Valor de b: ");
		b= Integer.parseInt(teclado.nextLine());
		if (a>b){
			System.out.println("A é maior que B.");
		}if (a==b){
			System.out.println("A é igual a B.");
		}
		
	}
}
