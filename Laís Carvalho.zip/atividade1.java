//Lais Carvalho de lima - 2ºTI VESPERTINO
package atividadelingp;
import java.util.Scanner;
public class atividade1 {
	
	public static void main(String[] args) {
		// questão 1
		Scanner teclado=new Scanner(System.in);
		int a,b, x, y,z,w;
		System.out.println("Valor de A: ");
		a = Integer.parseInt(teclado.nextLine());
		System.out.println("Valor de B: ");
		b = Integer.parseInt(teclado.nextLine());
		
		//soma
		x=a+b;
		System.out.println("Soma : "+x);
		
		//subtração
		y=a-b;
		System.out.println("Subtração: "+y);
		
		//multiplicação
		z=a*b;
		System.out.println("Multiplicação: "+z);
		
		//divisão
		w=a/b;
		System.out.println("Divisão: "+w);
		
	}
}
