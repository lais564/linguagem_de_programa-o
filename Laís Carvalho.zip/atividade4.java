zpackage atividadelingp;

public class atividade4 {
	
	public static void main(String[] args) {
		// questão 4
		int x=2;
		int y=3;
		
		System.out.printf( "x = %d\n", 2);
	    System.out.printf( "Value of %d + %d is %d\n", 2, 2, (2 +2) );
		System.out.printf( "x =" );
		System.out.printf( "%d %d\n", (2 + 3), ( 3 + 2) );
	}
}
