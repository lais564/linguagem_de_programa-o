package atividadelingp;
import java.util.Scanner;
public class atividade3 {
	
	public static void main(String[] args) {
		// questão 3
		Scanner teclado=new Scanner(System.in);
		float base=45.5f, altura= 32f, x;
		x = base*altura;
		System.out.println("Área do retangulo é igual a: "+x);
		
	}
}
