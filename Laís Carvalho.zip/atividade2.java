package atividadelingp;
import java.util.Scanner;
public class atividade2 {
	
	public static void main(String[] args) {
		// questão 2
		Scanner teclado=new Scanner(System.in);
		double a,b, c, x, y;
		System.out.println("Nota 1: ");
		a=Integer.parseInt(teclado.nextLine());
		
		System.out.println("Nota 2: ");
		b=Integer.parseInt(teclado.nextLine());
		
		System.out.println("Nota 3: ");
		c=Integer.parseInt(teclado.nextLine());
		
		
		x= a + b+ c;
		System.out.println("Soma: "+x);
		
		y=x/3.0;
		System.out.println("Média: "+y);

	}
}
