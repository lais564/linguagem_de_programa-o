package atividadelingp;
import java.util.Scanner;
public class atividade7 {
	
	public static void main(String[] args) {
		// questão 7
		Scanner teclado=new Scanner(System.in);
		
		int a;
		System.out.println("Digite um número inteiro: ");
		a= Integer.parseInt(teclado.nextLine());
		
		
		if ( a % 2 == 0) {
			System.out.printf("Este número é par.");
		} else {
			System.out.printf("Este número é impar.");
		}
	}
}
